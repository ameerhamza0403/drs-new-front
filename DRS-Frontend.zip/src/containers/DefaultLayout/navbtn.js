import React from 'react';
import '..//..//scss/customstyles/navbtn.css';

let MyNavBar =()=>{
  return(
    <div className='row bread'>
      <ul className="nav bread">
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#"><i className='cui-dashboard'></i>&nbsp;&nbsp;&nbsp;Link</a>
  </li>

</ul>
      </div>
  )
}

export default MyNavBar;

module.exports = [
	{ value: 'John Smith', label: 'John Smith', email: 'john@smith.com' },
	{ value: 'Merry Jane', label: 'Merry Jane', email: 'merry@jane.com' },
	{ value: 'Stan Hoper', label: 'Stan Hoper', email: 'stan@hoper.com' }
];
